Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information.

To install and run this example, simply check it out and run the following Maven command

```
$ pwd
/path/to/checkout/dir
$ cd jOOQ-examples/jOOQ-jpa-example-entities
...
$ mvn clean install
$ cd ../jOOQ-examples/jOOQ-jpa-example
...
$ mvn clean install

```

Note that the JPA-annotated entities need to be placed in a dependency of the example project